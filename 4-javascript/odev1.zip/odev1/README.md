### Javascript Clock

**Javascript** prompt ile kullanıcıdan isim bilgisi alındı.
**Javascript** ile anlık tarih ve zamanı alarak bir sayaç oluşturuldu.

***************************************

![Proje Görünümü] (img/projectview.jpg)